﻿return {
  ["default"] = {
        ver = "2.040r.0625",
        dist = "微笑问道",
        ftpHost = "127.0.0.1",
        ftpPort = "21",
        ftpUser = "atm",
        ftpPwd = "",
        accList = {"110001runlmv6i","110001ies8gr3v","110001ikurjy1h","110001mu07vmpk","110001gs455hit"},
        service_infos = {
              { ["key"] = "qq", ["value"] = {} },
              { ["key"] = "qq_group", ["value"] = {} },
              { ["key"] = "wx", ["value"] = {} },
              { ["key"] = "tel", ["value"] = {} },
        },
        new_package_first_version = "2.040r.0625",
        force_update_version = "2.040r.0625",
        update_package_time = "2018-01-25 04:59:59",
    },

  ["groups"] ={"凌云之巅",},
       ["凌云之巅"] = { aaa = "117.24.6.15:14721", group = "凌云之巅", state = 4, isNew = true },
}
