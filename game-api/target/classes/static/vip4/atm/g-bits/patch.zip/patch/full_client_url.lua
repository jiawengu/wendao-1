return {
  ["g-bits"] = "https://atmdl.leiting.com/full/2.019r.0410_asktao_20180412.apk",
}