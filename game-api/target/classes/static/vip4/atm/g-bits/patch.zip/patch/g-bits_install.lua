return {
    ["url"] = "https://atmdl.leiting.com/full/g-bits_install.png",
    ["checksum"] = "392629c2c5aa7be6f61d3b39e5a514ed",
}